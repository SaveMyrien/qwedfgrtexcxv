# -*- coding: utf-8 -*-
import sys
import re
import urllib.parse
import json
import requests
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

API_BASE_URL = "https://lamovie.org"
API_SEARCH = f"{API_BASE_URL}/wp-api/v1/search"
API_PLAYER = f"{API_BASE_URL}/wp-api/v1/player"

HEADERS_DEFAULT = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://lamovie.org/",
    "Origin": "https://lamovie.org"
}

def unpack_dean_edwards(packed_code):
    try:
        match = re.search(r"}\s*\(\s*'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,'(.*?)'\.split\('\|'\)", packed_code, re.DOTALL)
        if not match:
            return None

        p, a, c, k = match.groups()
        a = int(a)
        c = int(c)
        k = k.split('|')

        def e(c, a):
            return "" if c < a else e(c // a, a) + (chr(c % a + 29) if c % a > 35 else "0123456789abcdefghijklmnopqrstuvwxyz"[c % a])

        for idx in range(c - 1, -1, -1):
            if idx < len(k) and k[idx]:
                key = e(idx, a)
                p = re.sub(r'\b' + re.escape(key) + r'\b', k[idx], p)

        return p
    except Exception as err:
        xbmc.log(f"[CineAddon] Error en unpack_dean_edwards: {err}", xbmc.LOGERROR)
        return None

def extract_vimeos_m3u8(embed_url):
    try:
        if embed_url.startswith("//"):
            embed_url = "https:" + embed_url

        session = requests.Session()
        res = session.get(embed_url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36",
            "Referer": "https://goodstream.one/",
            "Origin": "https://goodstream.one"
        }, timeout=10)

        if res.status_code != 200:
            return None

        html = res.text
        raw_m3u8 = None

        unpacked = unpack_dean_edwards(html)
        if unpacked:
            match = re.search(r'file\s*:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', unpacked, re.I)
            if match:
                raw_m3u8 = match.group(1)
            else:
                match_token = re.search(r'(https?://[^\s"\'<>\\]+?\.m3u8\?[^\s"\'<>\\]+)', unpacked, re.I)
                if match_token:
                    raw_m3u8 = match_token.group(1)

        if not raw_m3u8:
            match = re.search(r'file\s*:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', html, re.I)
            if match:
                raw_m3u8 = match.group(1)
            else:
                match_token = re.search(r'(https?://[^\s"\'<>\\]+?\.m3u8\?[^\s"\'<>\\]+)', html, re.I)
                if match_token:
                    raw_m3u8 = match_token.group(1)

        if raw_m3u8:
            return raw_m3u8.strip().replace('&amp;', '&')

    except Exception as err:
        xbmc.log(f"[CineAddon] Error extrayendo Vimeos: {err}", xbmc.LOGERROR)

    return None

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def execute_play(m3u8_url, title=""):
    origin_header = "https://goodstream.one"
    referer_header = "https://goodstream.one/"
    user_agent_header = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"

    headers_str = (
        f"Referer={referer_header}&"
        f"Origin={origin_header}&"
        f"User-Agent={user_agent_header}"
    )

    play_item = xbmcgui.ListItem(path=m3u8_url)
    play_item.setInfo("video", {"title": title})
    play_item.setContentLookup(False)
    play_item.setMimeType("application/vnd.apple.mpegurl")

    play_item.setProperty("inputstream", "inputstream.adaptive")
    play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
    play_item.setProperty("inputstream.adaptive.stream_headers", headers_str)
    play_item.setProperty("inputstream.adaptive.manifest_headers", headers_str)

    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        xbmc.Player().play(m3u8_url, play_item)

def play_from_bingie(title, year="", season="", episode=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create("LaMovie", f"Buscando enlaces para: {title}")
    dialog.update(25, "Consultando catálogo...")

    search_query = title
    search_url = f"{API_SEARCH}?filter=%7B%7D&postType=any&q={urllib.parse.quote(search_query)}&postsPerPage=10"
    
    try:
        res = requests.get(search_url, headers=HEADERS_DEFAULT, timeout=10)
        posts = res.json().get("data", {}).get("posts", [])
    except Exception as e:
        xbmc.log(f"[CineAddon] Error en búsqueda Bingie: {e}", xbmc.LOGERROR)
        posts = []

    if not posts:
        dialog.close()
        xbmcgui.Dialog().notification("LaMovie", "No se encontró el contenido", xbmcgui.NOTIFICATION_WARNING)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    dialog.update(50, "Obteniendo servidores...")
    selected_post = posts[0]
    post_id = selected_post.get("_id")

    player_url = f"{API_PLAYER}?postId={post_id}&demo=0"
    try:
        res_player = requests.get(player_url, headers=HEADERS_DEFAULT, timeout=10)
        embeds = res_player.json().get("data", {}).get("embeds", [])
    except Exception as e:
        xbmc.log(f"[CineAddon] Error obteniendo reproductor: {e}", xbmc.LOGERROR)
        embeds = []

    valid_servers = []
    for embed in embeds:
        url = embed.get("url", "")
        if url and ("vimeos" in url or "goodstream" in url):
            server_name = embed.get("server", "Servidor Directo")
            quality = embed.get("quality", "HD")
            lang = embed.get("lang", "Latino")
            valid_servers.append({
                "name": f"{server_name} [{quality}] ({lang})",
                "url": url
            })

    if not valid_servers:
        dialog.close()
        xbmcgui.Dialog().notification("LaMovie", "Sin servidores directos disponibles", xbmcgui.NOTIFICATION_ERROR)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    dialog.update(75, "Seleccionando servidor...")
    chosen_server = None
    if len(valid_servers) == 1:
        chosen_server = valid_servers[0]
    else:
        dialog.close()
        options = [srv["name"] for srv in valid_servers]
        choice = xbmcgui.Dialog().select(f"Servidores para {title}", options)
        if choice == -1:
            if HANDLE >= 0:
                xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        chosen_server = valid_servers[choice]

    if dialog.isdialogopen():
        dialog.update(90, "Extrayendo stream...")
        dialog.close()

    m3u8_url = extract_vimeos_m3u8(chosen_server["url"])
    if not m3u8_url:
        xbmcgui.Dialog().notification("LaMovie", "Error al extraer stream M3U8", xbmcgui.NOTIFICATION_ERROR)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    execute_play(m3u8_url, title)

def show_main_menu():
    xbmcplugin.setContent(HANDLE, "videos")

    menu_items = [
        {"title": "🎬 Películas LaMovie", "action": "show_catalog", "postType": "movies", "page": 1},
        {"title": "📺 Series LaMovie", "action": "show_catalog", "postType": "tvshows", "page": 1},
        {"title": "🔍 Buscar", "action": "search_dialog"}
    ]

    for item_data in menu_items:
        url = build_url(item_data)
        item = xbmcgui.ListItem(label=item_data["title"])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def show_catalog(post_type="movies", page=1):
    xbmcplugin.setContent(HANDLE, "movies" if post_type == "movies" else "tvshows")

    req_url = f"{API_SEARCH}?filter=%7B%7D&postType={post_type}&page={page}&postsPerPage=24"
    try:
        res = requests.get(req_url, headers=HEADERS_DEFAULT, timeout=10)
        posts = res.json().get("data", {}).get("posts", [])
    except Exception as e:
        xbmc.log(f"[CineAddon] Error cargando catálogo: {e}", xbmc.LOGERROR)
        posts = []

    for post in posts:
        title = post.get("title", "Sin título")
        post_id = post.get("_id")
        p_type = post.get("type", "movies")
        overview = post.get("overview", "")
        rating = post.get("rating", 0)
        year = post.get("year", "")

        poster = post.get("images", {}).get("poster", "")
        if poster and not poster.startswith("http"):
            poster = f"{API_BASE_URL}{poster}"

        backdrop = post.get("images", {}).get("backdrop", "")
        if backdrop and not backdrop.startswith("http"):
            backdrop = f"{API_BASE_URL}{backdrop}"

        url = build_url({"action": "play", "title": title})

        item = xbmcgui.ListItem(label=title)
        item.setArt({
            "poster": poster,
            "thumb": poster,
            "fanart": backdrop or poster,
            "banner": backdrop
        })

        item.setInfo("video", {
            "title": title,
            "plot": overview,
            "rating": float(rating) if rating else 0.0,
            "year": int(year) if str(year).isdigit() else 0,
            "mediatype": "movie" if p_type == "movies" else "tvshow"
        })
        item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    if posts:
        next_url = build_url({"action": "show_catalog", "postType": post_type, "page": int(page) + 1})
        item_next = xbmcgui.ListItem(label="➡️ Siguiente Página...")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=item_next, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def search_dialog():
    dialog = xbmcgui.Dialog()
    query = dialog.input("Buscar en LaMovie:", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        return

    play_from_bingie(title=query)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if not action:
        show_main_menu()
    elif action == "play":
        play_from_bingie(
            title=params.get("title", ""),
            year=params.get("year", ""),
            season=params.get("season", ""),
            episode=params.get("episode", "")
        )
    elif action == "show_catalog":
        show_catalog(params.get("postType", "movies"), int(params.get("page", 1)))
    elif action == "search_dialog":
        search_dialog()

if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[2]:
        router(sys.argv[2][1:])
    else:
        router("")